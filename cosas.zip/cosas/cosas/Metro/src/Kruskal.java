import java.util.ArrayList;
import java.util.List;

public class Kruskal {

	public static int kruskal(List<Conexion> conexionList) {
		int resultado = 0;
		List<Integer> nodoVisitado = new ArrayList<Integer>(conexionList.size());
		for(int i = 0; i<conexionList.size(); i++) {
			nodoVisitado.add(i);
		}
		for(Conexion conex: conexionList) {
			int indiceActual = conex.nodoA;
			while(indiceActual != nodoVisitado.get(indiceActual)) {
				indiceActual = nodoVisitado.get(indiceActual);
			}
			int nodoA = nodoVisitado.get(indiceActual);
			indiceActual = conex.nodoB;
			while(indiceActual != nodoVisitado.get(indiceActual)) {
				indiceActual = nodoVisitado.get(indiceActual);
			}
			int nodoB = nodoVisitado.get(indiceActual);
			if(nodoA != nodoB) {
				nodoVisitado.set(conex.nodoB, conex.nodoA);
				resultado += conex.peso;
			}
		}
		return resultado;
	}
}





