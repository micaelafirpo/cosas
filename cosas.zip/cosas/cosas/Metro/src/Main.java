import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		List<Conexion> conexionList = new ArrayList<Conexion>();
		conexionList = GestorDeArchivos.leerArchivo();
		GestorDeArchivos.escribirArchivo(Kruskal.kruskal(conexionList));
	}

}
