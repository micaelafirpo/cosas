import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GestorDeArchivos {
	
	private static String nombreArch = "ambasConexionesSiemprePosibles";
	
	public static List<Conexion> leerArchivo(){
		List<Conexion> conexionList;
		
		try {
			Scanner scanner = new Scanner(new File(nombreArch+".in"));
			conexionList = new ArrayList<Conexion>();
			int conexMaximas = scanner.nextInt();
			int cantTuneles = scanner.nextInt();
			int cantPuentes = scanner.nextInt();
			scanner.nextLine();
			
			while(scanner.hasNextLine()) {
				int nodoA = scanner.nextInt();
				int nodoB = scanner.nextInt();
				conexionList.add(cantTuneles > 0 ? 0 : conexionList.size(), new Conexion(nodoA, nodoB, cantTuneles > 0 ? 0 : 1 ));
				cantTuneles--;
			}
			scanner.close();
		}catch(Exception e) {
			conexionList = null;
			System.out.println(e.getMessage());
		}
		
		return conexionList;
	}
	
	public static void escribirArchivo(int resultado) {
		FileWriter fichero = null;
		PrintWriter pw = null;
		try {				
			fichero = new FileWriter(nombreArch+".out");
			pw = new PrintWriter(fichero);
			pw.println(resultado);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != fichero)
					fichero.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
}







