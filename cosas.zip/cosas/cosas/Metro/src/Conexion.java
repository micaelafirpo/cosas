
public class Conexion {
	int nodoA;
	int nodoB;
	int peso;
	
	Conexion(int nodoA,	int nodoB, int peso){
		this.nodoA = nodoA;
		this.nodoB = nodoB;
		this.peso = peso;
	}
}
