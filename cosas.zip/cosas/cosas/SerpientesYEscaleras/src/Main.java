
public class Main {
	
	public static void main(String[] args) {
		Grafo grafo = GestorDeArchivos.leerArchivo();
		//grafo.verListaAdy();
		System.out.println(grafo.BFS(1));
		
		
	}
}
