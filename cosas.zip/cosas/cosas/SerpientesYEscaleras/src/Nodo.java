
public class Nodo {
	int numeroNodo;
	 
    // `min_dist` almacena la distancia m�nima de un nodo desde el v�rtice inicial
    int minDist;
 
    public Nodo(int numeroNodo, int minDist)
    {
        this.numeroNodo = numeroNodo;
        this.minDist = minDist;
    }

	public void setMinDist(int minDist) {
		this.minDist = minDist;
	}

	public int getNumeroNodo() {
		return numeroNodo;
	}

	public int getMinDist() {
		return minDist;
	}
	
	
    
   
}
