import java.io.File;
import java.util.Scanner;

public class GestorDeArchivos {
	private static String nombre = "juego01";
	
	public static Grafo leerArchivo() {
		Grafo grafo = null;
		try {

			Scanner scanner = new Scanner(new File(nombre+".in"));
			grafo = new Grafo();
			int cantS = scanner.nextInt();
			for(int i = 0; i<cantS; i++) {
				int cola = scanner.nextInt();
				int cabeza = scanner.nextInt();
				grafo.agregarSerpiente(cola, cabeza);
			}
			
			int cantE = scanner.nextInt();
			for(int i = 0; i<cantE; i++) {
				int inicio = scanner.nextInt();
				int fin = scanner.nextInt();
				grafo.agregarEscalera(inicio, fin);
			}

			scanner.close();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
		return grafo;
	}

}
