import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Queue;

public class Grafo {
	
	private ArrayList<ArrayList<Integer>> adyList;
	private ArrayList<Nodo> nodoList;
	private HashMap<Integer,Integer> escaleraMap;
	private HashMap<Integer,Integer> serpienteMap;
	
	Grafo(){
		adyList = new ArrayList<ArrayList<Integer>>(26);
		nodoList = new ArrayList<Nodo>(26);
		adyList.add(0, new ArrayList<Integer>());
		nodoList.add(new Nodo(0,0));
		for(int i = 1; i<25; i++) {
			//System.out.print("Agregando nodo "+i+" a lista de adyacencias");
			adyList.add(i, new ArrayList<Integer>());
			ArrayList<Integer> l = adyList.get(i);
			l.add(i+1);
			//System.out.println(" que es adyacente con "+(i+1));
			
			nodoList.add(new Nodo(i, i));
		}
		adyList.add(25, new ArrayList<Integer>());
		escaleraMap = new HashMap<Integer,Integer>();
		serpienteMap = new HashMap<Integer,Integer>();
	}
	
	public void agregarSerpiente(int cola, int cabeza) {
		ArrayList<Integer> l = adyList.get(cabeza);
		l.add(cola);
		//Nodo n = nodoList.get(cabeza-1);
		serpienteMap.put(cabeza,cola);
		//n.setCabezaSerpiente(true);
	}
	
	public void agregarEscalera(int inicio, int fin) {
		ArrayList<Integer> l = adyList.get(inicio);
		l.add(fin);
		//Nodo n = nodoList.get(inicio-1);
		//n.setInicioEscalera(true);
		escaleraMap.put(inicio, fin);
		//n = nodoList.get(fin-1);
		//n.setMinDist(inicio-1);
	}
	
	public void verListaAdy() {
		for(int indice = 1; indice < 25; indice ++) {
			System.out.println("Casillero "+indice+" adyacente con:");
			for(int i: adyList.get(indice)) {
				System.out.print("\t"+i+" ");
				Nodo n = nodoList.get(i-1);
				//System.out.print("Tiene escalera? "+n.inicioEscalera);
				//System.out.print(" Tiene serpiente? "+n.cabezaSerpiente);
				System.out.println(" Minima distancia al inicio: "+n.minDist);
			}
		}
	}
	
    public int BFS(int nodoInicial)
    {
    	int lanzamientos = 1;
    	boolean finAlcanzado = false;
        while(!finAlcanzado) {
        	nodoInicial = buscarMejorNodo(nodoInicial);
        	if(nodoInicial != 25) {
        		lanzamientos++;
        	}else {
        		finAlcanzado = true;
        	}
        }
        
        return lanzamientos;
    }

	
	//busca el nodo mas lejano al que pueda ir
	public int buscarMejorNodo(int nodoActual) {
		int maxNodoAlcanzable = nodoActual+6 >= 25 ? 25: nodoActual+6;
		int maxNodoAlcanzableTemp = maxNodoAlcanzable;
		int mayorSalto = 0;
		int mejorNodo = 0;
		boolean encontrado = false;
		
		for(int i = 1; i <= 6; i++) {
			if(escaleraMap.containsKey(maxNodoAlcanzableTemp)){
				System.out.println(maxNodoAlcanzableTemp);
				if(escaleraMap.get(maxNodoAlcanzableTemp) > mayorSalto) {
					System.out.println("Mejor opcion con escalera temporal "+maxNodoAlcanzableTemp);
					encontrado = true;
					mayorSalto = escaleraMap.get(maxNodoAlcanzableTemp);
					mejorNodo = escaleraMap.get(maxNodoAlcanzableTemp);
				}
			}
		
			maxNodoAlcanzableTemp--;

		}
		
		if(!encontrado) {
			maxNodoAlcanzableTemp = maxNodoAlcanzable;
			while(!encontrado) {
				if(!serpienteMap.containsKey(maxNodoAlcanzableTemp)){
					//System.out.println("Mejor opcion sin serpiente temporal "+maxNodoAlcanzableTemp);
					encontrado = true;
					mejorNodo = maxNodoAlcanzableTemp;
				}
				else {
					//System.out.println("Nodo "+maxNodoAlcanzableTemp+" tiene serpiente");
					maxNodoAlcanzableTemp--;
				}
			}
		}
		
		System.out.println(">>>>>>   Mejor opcion definitiva "+mejorNodo);
		System.out.println("---------------------------------");
		System.out.println();
		return mejorNodo;
	}
	
	

}
