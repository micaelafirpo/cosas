
public class ParejaNodo {
	public int nodoA;
	public int nodoB;
	
	ParejaNodo(int nodoA, int nodoB){
		this.nodoA = nodoA;
		this.nodoB = nodoB;
	}
}
