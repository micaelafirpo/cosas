import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Grafo {

	
	public static Resultado kruskalElectrificado(Mapa mapa) {
		List<Conexion> conexList = mapa.costoConexiones;		
		conexList.sort(null);
		Resultado res = new Resultado();
		List<Integer> nodoVisitado = new ArrayList<Integer>(mapa.cantidadCiudades);
		nodoVisitado.add(-1);
		ArrayList<Boolean> ciudadConLuz = new ArrayList<Boolean>();
		ciudadConLuz.add(false);

		Map<Integer,ArrayList<Integer>> mapaConexiones = new HashMap<Integer,ArrayList<Integer>>();
		for(int i = 1; i<=mapa.cantidadCiudades; i++) {
			int valor;
			if(mapa.ciudadesConCentral.contains(i)) {
				valor = mapa.ciudadesConCentral.get(0);
				ciudadConLuz.add(i, true);
			}else {
				ciudadConLuz.add(i, false);
				valor = i;
			}
			mapaConexiones.put(i, new ArrayList<Integer>());
			nodoVisitado.add(valor);
		}
		
		int costo = 0;
		int ciudadesPorConectar = mapa.cantidadCiudades - mapa.ciudadesConCentral.size();

		for(Conexion conex: conexList) {
			if(ciudadesPorConectar == 0) {
				break;
			}
			int indiceActual = conex.nodoA;
			while(indiceActual != nodoVisitado.get(indiceActual)) {
				indiceActual = nodoVisitado.get(indiceActual);
			}
			int nodoA = nodoVisitado.get(indiceActual);
			
			indiceActual = conex.nodoB;
			while(indiceActual != nodoVisitado.get(indiceActual)) {
				indiceActual = nodoVisitado.get(indiceActual);
			}
			int nodoB = nodoVisitado.get(indiceActual);
			if(nodoA != nodoB && (ciudadConLuz.get(conex.nodoA)==false || ciudadConLuz.get(conex.nodoB)==false) ) {
				nodoVisitado.set(conex.nodoB, conex.nodoA);
				costo += conex.pesoArista;
				res.agregarPareja(conex.nodoA, conex.nodoB);	
				
				ArrayList<Integer> conexionesExistentes = mapaConexiones.get(conex.nodoA);
				conexionesExistentes.add(conex.nodoB);
				if(ciudadConLuz.get(conex.nodoB)) {
					ciudadConLuz.set(conex.nodoA, true);
					for(int nuevaCiudadConLuz: conexionesExistentes) {
						ciudadConLuz.set(nuevaCiudadConLuz, true);
					}
				}
				
				conexionesExistentes = mapaConexiones.get(conex.nodoB);
				conexionesExistentes.add(conex.nodoA);
				if(ciudadConLuz.get(conex.nodoA)) {
					ciudadConLuz.set(conex.nodoB, true);
					for(int nuevaCiudadConLuz: conexionesExistentes) {
						ciudadConLuz.set(nuevaCiudadConLuz, true);
					}
				}
				
				ciudadesPorConectar--; 

			}
		}
		res.agregarCosto(costo);
		
		return res;
	}
}
