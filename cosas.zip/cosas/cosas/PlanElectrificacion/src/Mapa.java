import java.util.ArrayList;
import java.util.List;

public class Mapa {
	public List<Integer> ciudadesConCentral;
	public List<Conexion> costoConexiones;
	public int[][] costoConexionesMatriz;
	public int cantidadCiudades;
	
	Mapa(int cantCiudadesConCentral, int cantidadCiudades ){
		ciudadesConCentral = new ArrayList<Integer>(cantCiudadesConCentral);
		costoConexionesMatriz = new int[cantidadCiudades][];
		costoConexiones = new ArrayList<Conexion>(cantidadCiudades);
		this.cantidadCiudades = cantidadCiudades;
	}
	
	public void agregarCiudadConCentral(int ciudad) {
		this.ciudadesConCentral.add(ciudad);
	}
	
	public void agregarCiudadMatriz(int ciudadOrigen, int ciudadDestino, int costo) {
		this.costoConexionesMatriz[ciudadOrigen-1][ciudadDestino-1] = costo;
		this.costoConexionesMatriz[ciudadDestino-1][ciudadOrigen-1] = costo;
	}
	
	public void agregarCiudad(int ciudadOrigen, int ciudadDestino, int costo) {
		Conexion conex = new Conexion(ciudadOrigen, ciudadDestino, costo);
		this.costoConexiones.add(conex);
	}
}
