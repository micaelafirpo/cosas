
public class Conexion implements Comparable<Conexion>{
	public int nodoA;
	public int nodoB;
	public int pesoArista;
	
	Conexion(int nodoA, int nodoB, int pesoArista){
		this.nodoA = nodoA;
		this.nodoB = nodoB;
		this.pesoArista = pesoArista;
	}

	@Override
	public int compareTo(Conexion o) {
		return this.pesoArista - o.pesoArista;
	}
	
}
