import java.util.ArrayList;
import java.util.List;

public class Resultado {
	public int costo;
	public List<ParejaNodo> pnList;
	
	Resultado(){
		pnList = new ArrayList<ParejaNodo>();
	}
	
	public void agregarPareja(int nodoA, int nodoB) {
		ParejaNodo p = new ParejaNodo(nodoA, nodoB);
		pnList.add(p);
	}
	
	public void agregarCosto(int costo) {
		this.costo = costo;
	}
}
