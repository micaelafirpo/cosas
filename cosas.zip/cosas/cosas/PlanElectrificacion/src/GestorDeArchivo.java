import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;

public class GestorDeArchivo {
	private static String nombre = "unicaCentral"; 
	
	public static Mapa leerArchivo(Mapa mapa) {
		try {
			Scanner scanner = new Scanner(new File(nombre+".in"));
			int cantCiudades = scanner.nextInt();
			int ciudadesConCentral = scanner.nextInt();
			scanner.nextLine();
			mapa = new Mapa(ciudadesConCentral, cantCiudades);
			for(int i = 0; i<ciudadesConCentral; i++) {
				int ciudadConCentral = scanner.nextInt();
				mapa.agregarCiudadConCentral(ciudadConCentral);
			}
			scanner.nextLine();
			
			for(int i = 1; i<cantCiudades; i++) {
				String linea = scanner.nextLine();
				String[] costos = linea.split(" ");
				
				//System.out.println("Conectando ciudad "+i);
				for(int j = i; j<cantCiudades; j++) {
					//System.out.println("\tcon ciudad "+(j+1)+ " con peso "+Integer.valueOf(costos[j]));
					mapa.agregarCiudad(i, j+1, Integer.valueOf(costos[j]));
				}
			}
			scanner.close();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return mapa;
	}
	
	public static void escribirArchivo(Resultado res) {
		FileWriter fw = null;
		PrintWriter pw = null;
		try {
			fw = new FileWriter(nombre+".out");
			pw = new PrintWriter(fw);
			pw.println(res.costo);
			for(ParejaNodo pj: res.pnList) {
				pw.println(pj.nodoA + " " + pj.nodoB);
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}finally {
			try {
				if(fw != null) {
					fw.close();
				}
			}catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}
}
