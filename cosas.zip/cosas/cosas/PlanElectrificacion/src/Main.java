
public class Main {

	public static void main(String[] args) {
		Mapa mapa = null;
		mapa = GestorDeArchivo.leerArchivo(mapa);
		GestorDeArchivo.escribirArchivo(Grafo.kruskalElectrificado(mapa)); 
	}

}
