public class Conexion {
	private int nodoA;
	private int nodoB;
	private int distancia;
	
	Conexion(int nodoA, int nodoB){
		this.nodoA = nodoA;
		this.nodoB = nodoB;
		this.distancia = 1;
	}

	public int getNodoA() {
		return nodoA;
	}

	public int getNodoB() {
		return nodoB;
	}

	public int getDistancia() {
		return distancia;
	}
	
	
}

