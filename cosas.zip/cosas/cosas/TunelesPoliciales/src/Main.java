import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Main {

	static ArrayList<ArrayList<Integer>> posiblesCaminos;

	public static void main(String[] args) {
		Grafo grafo = GestorDeArchivos.leerArchivo();
		posiblesCaminos = new ArrayList<ArrayList<Integer>>(grafo.nodoConMovil.size());
		for (int nodoInicial : grafo.nodoConMovil) {
			grafo.dijkstra(nodoInicial - 1);
			posiblesCaminos.add(grafo.getCamino(grafo.nodoEmergencia - 1));
		}

		posiblesCaminos = removerSinCamino(posiblesCaminos);
		ordenar(posiblesCaminos);

		GestorDeArchivos.escribirArchivo(posiblesCaminos);

	}

	public static ArrayList<ArrayList<Integer>> removerSinCamino(ArrayList<ArrayList<Integer>> posiblesCaminos) {
		ArrayList<ArrayList<Integer>> posiblesCaminosTemp = new ArrayList<ArrayList<Integer>>(posiblesCaminos.size());
		for (ArrayList<Integer> l : posiblesCaminos) {
			if (l.size() != 0) {
				posiblesCaminosTemp.add(l);
			}
		}
		return posiblesCaminosTemp;
	}

	public static void ordenar(ArrayList<ArrayList<Integer>> posiblesCaminos) {
//        for (ArrayList<Integer> l : posiblesCaminos) {
//            Collections.sort(l);
//        }
		Collections.sort(posiblesCaminos, new Comparator<ArrayList<Integer>>() {
			public int compare(ArrayList<Integer> o1, ArrayList<Integer> o2) {
				return o1.size() - o2.size();
			}
		});

	}

}
