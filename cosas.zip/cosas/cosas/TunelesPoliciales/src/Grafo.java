import java.util.ArrayList;
import java.util.Collections;

public class Grafo {
	
	public ArrayList<Integer> nodoConMovil;
	public int nodoEmergencia;
	
	private int matrizAdy[][];
	private int predecesores[];	
	private int nodoInicial;
	
	private boolean correspondeCamino;
	
	Grafo(int moviles, int matriz[][]){
		nodoConMovil = new ArrayList<Integer>(moviles);
		this.matrizAdy = matriz;
		this.predecesores = new int[matrizAdy.length];
	}
		
	public void agregarMovil(int nodo) {
		nodoConMovil.add(nodo);
	}
		
	public void setNodoEmergencia(int ne) {
		this.nodoEmergencia = ne;
	}
	
	
	
	public int hallarNodoMinDist(boolean[] conjSol, int[] dist) {
		int minKey = Integer.MAX_VALUE;
		int nodo = 0;
		
		for (int i = 0; i < matrizAdy.length; i++) {
			if (conjSol[i] == false && minKey > dist[i]) {
				minKey = dist[i];
				nodo = i;
			}
		}

		return nodo;
	}
	
	public int[] dijkstra(int nodoInicial) {
		correspondeCamino = false;
		boolean conjSol[] = new boolean[matrizAdy.length];

		int dist[] = new int[matrizAdy.length];
		int infinidad = Integer.MAX_VALUE;
		this.nodoInicial = nodoInicial;
		
		for (int i = 0; i < matrizAdy.length; i++) {
			dist[i] = infinidad;
			predecesores[i] = nodoInicial;
		}
		
		dist[nodoInicial] = 0;

		for (int i = 0; i < matrizAdy.length; i++) {
			int nodoActual = hallarNodoMinDist(conjSol, dist);

			conjSol[nodoActual] = true;

			for (int vecino = 0; vecino < matrizAdy.length; vecino++) {	

				if (matrizAdy[nodoActual][vecino] > 0) {

//System.out.println("El nodo "+(vecino+1)+" tiene movil? "+!nodoConMovil.contains(vecino+1));
					if (conjSol[vecino] == false && matrizAdy[nodoActual][vecino] != infinidad && !nodoConMovil.contains(vecino+1)) {
						correspondeCamino = true;
						int minimoTentativo = dist[nodoActual] + matrizAdy[nodoActual][vecino];
						if (minimoTentativo < dist[vecino])	{
							
							dist[vecino] = minimoTentativo;
							predecesores[vecino] = nodoActual;
							
						}
					}
				}
			}			
		}	

		return dist;
	}
	
	public ArrayList<Integer> getCamino(int nodoHasta) {
		int i = nodoHasta;
		ArrayList<Integer> camino = new ArrayList<Integer>();
		if(correspondeCamino) {
			camino.add((i+1));
			while (i != nodoInicial ) {
				
				i = predecesores[i];
				camino.add((i+1));
			}
			Collections.reverse(camino);			
		}
		return camino;
	}
	
}
