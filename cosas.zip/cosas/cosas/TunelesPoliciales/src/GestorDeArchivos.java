import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class GestorDeArchivos {
private static String nombre = "movilesMismaDistancia";
	
	public static Grafo leerArchivo() {
		Grafo grafo = null;
		try {
			Scanner scanner = new Scanner(new File(nombre+".in"));

			int cantEstaciones = scanner.nextInt();
			int cantConexiones = scanner.nextInt();
			int cantMoviles = scanner.nextInt();
			scanner.nextLine();
			int[][] matriz = new int[cantEstaciones][cantEstaciones];

			for(int i = 0; i<cantConexiones; i++) {
				int conexNodoA = scanner.nextInt();
				int conexNodoB = scanner.nextInt();
				matriz[conexNodoA-1][conexNodoB-1] = 1;
				matriz[conexNodoB-1][conexNodoA-1] = 1;
			}
			scanner.nextLine();

			grafo = new Grafo(cantMoviles, matriz);
			
			for(int i = 0; i<cantMoviles; i++) {
				int nodoConMovil = scanner.nextInt();
				grafo.agregarMovil(nodoConMovil);
			}
			scanner.nextLine();

			int nodoEmergencia = scanner.nextInt();
			
			grafo.setNodoEmergencia(nodoEmergencia);

			scanner.close();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}		
		return grafo;
	}
	
	public static void escribirArchivo(ArrayList<ArrayList<Integer>> posiblesCaminos) {
		FileWriter fw = null;
		PrintWriter pw = null;
		try {
			fw = new FileWriter(nombre+".out");
			pw = new PrintWriter(fw);
			int mayorTiempo = 0;
			ArrayList<Integer> numeroMovil = new ArrayList<Integer>(3);
			
			ArrayList<Integer> subLista1 = posiblesCaminos.get(0);
			ArrayList<Integer> subLista2 = posiblesCaminos.get(1);
			ArrayList<Integer> subLista3 = posiblesCaminos.get(2);
			mayorTiempo = subLista3.size();							
			
			pw.println(mayorTiempo-1);
			int ultNodo1 = subLista1.remove(0);
			int ultNodo2 = subLista2.remove(0);
			int ultNodo3 = subLista3.remove(0);
			pw.print(ultNodo1+" ");
			pw.print(ultNodo2+" ");
			pw.println(ultNodo3+" ");
			
			while(subLista3.size() > subLista2.size()) {
				pw.print(ultNodo1+" ");
				pw.print(ultNodo2+" ");
				ultNodo3 = subLista3.remove(0);
				pw.println(ultNodo3+" ");
			}
			
			while(subLista2.size() >  subLista1.size()) {
				pw.print(ultNodo1+" ");
				ultNodo2 = subLista2.remove(0);
				pw.print(ultNodo2+" ");
				ultNodo3 = subLista3.remove(0);
				pw.println(ultNodo3+" ");
			}
			
			while(subLista1.size()>0) {
				ultNodo1 = subLista1.remove(0);
				pw.print(ultNodo1+" ");
				ultNodo2 = subLista2.remove(0);
				pw.print(ultNodo2+" ");
				ultNodo3 = subLista3.remove(0);
				pw.println(ultNodo3+" ");
			}
			
			
			
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}finally {
			try {
				if(fw != null) {
					fw.close();
				}
			}catch(Exception e2) {
				System.out.println(e2.getMessage());
			}
		}
	}
}
